public class Character
{
    private String name;
    private int hp;
    private int damage;
    private int mobility;
    
    public Character(String name, int hp, int damage, int mobility)
    {
        this.name = name;
        this.hp = hp;
        this.damage = damage;
        this.mobility = mobility;
    }
    
    public String getName()
    {
        return name;
    }
    
    public int getHp()
    {
        return hp;
    }
    
    public int getDamage()
    {
        return damage;
    }
    
    public int getMobility()
    {
        return mobility;
    }

    public int inflictDamage(String monsterType, String magicType)
    {
        return damage+(1*(mobility/100));
    }
    
    public String attackDialogue()
    {
        return "A fight begins!";
    }
    
    public String getDescription()
    {
        return "There is tension in the air as two sworn enemies are about to meet.";
    }
}