public class CharacterInfo
{
    //Character instances
    private String name;
    private int hp;
    private int damage;
    private int mobility;
    //Monster instances
    private String monsterType;
    //Player instances
    //Magician instances
    private String magicType;
    private boolean victory;
    //Swordsman instances
    private String swordType;
    
    //Character getters
    public CharacterInfo()
    {}
    
    public String getName()
    {
        return name;
    }
    
    public int getHp()
    {
        return hp;
    }
    
    public int getDamage()
    {
        return damage;
    }
    
    public int getMobility()
    {
        return mobility;
    }
    
    //Monster getters
    public String getMonsterType()
    {
        return monsterType;
    }
    
    //Player Getters
    public boolean getVictory()
    {
        return victory;
    }
    
    public String getPlayerType(String playerType, String key)
    {
        if(playerType.equals("1"))
        {
            return getMagicType(key);
        }
        else if (playerType.equals("2"))
        {
            return getSwordType(key);
        }
        else
        {
            System.out.println("EMPTY!!");
            return "";
        }
    }
    //Swordsman Getters
    public String getSwordType(String key)
    {
        if(key.equals("1"))
        {
            return ("Long Sword");
        }
        else if(key.equals("2"))
        {
            return ("Medium Slasher");
        }
        else
        {
            return ("Light Dagger");
        }
    }
    //Magician Getters
    public String getMagicType(String key)
    {
        if(key.equals("1"))
        {
            return "Water";
        }
        else if(key.equals("2"))
        {
            return "Fire";
        }
        else 
        {
            return "Earth";
        }      
    }
    
    //Monster setters
    public void setGiantTortoise()
    {
        name = "Giant Tortoise";
        hp = 40;
        damage = 5;
        mobility = 10;
        monsterType = "Earth";
    }
    
    public void setBlueDragon()
    {
        name = "Blue Dragon";
        hp = 30;
        damage = 10;
        mobility = 15;
        monsterType = "Water";
    }
    
    public void setCrimsonBat()
    {
        name = "Crimson Bat";
        hp = 20;
        damage = 25;
        mobility = 20;
        monsterType = "Fire";
    }
    //Player setters
    //Magician setter
    public void getMagician(String name, String magicIndex, boolean victory)
    {
        this.name = name;
        hp = 40;
        damage = 30;
        mobility = 10;
        this.victory = victory;
        magicType = getMagicType(magicIndex);
    }
    //Swordsman setter
    public void getSwordsMan(String name, String swordIndex, boolean victory)
    {
        this.name = name;
        hp = 50;
        damage = 20;
        mobility = 20;
        this.victory = victory;
        swordType = getSwordType(swordIndex);
    }
}