import java.lang.Math; 
import java.io.*;
import java.util.Scanner;

class Game
{
    public static void main(String [] args) 
    {
        printIntro();
        String play_as = chooseCharacter();
        fight3calamities(play_as);
    }
    
    public static String chooseCharacter()
    {
        String player = (inputString("Would you like to play as:"+ "\n"+"1.Magician"+ 
                    "\n" + "2.Swordsman"));
        if(player.equals("1") || player.equals("2"))
        {
            return player;
        }                
        System.out.println("ERROR INPUT! Please enter 1 or 2.");
        return chooseCharacter();
    }
    
    public static void print(String message)
    {
        System.out.println(message);
    }
    
    public static void fight3calamities(String playerType)
    {
        String playerName = inputString("Enter name: ");
        for(int i=0;i<3;i++)
        {
            CharacterInfo inm = new CharacterInfo();
            setMonsterValues(inm, i);
            CharacterInfo inp = new CharacterInfo();
            setPlayer(playerName, playerType, true, inp);//Needs to be edited
            
            Character m = new Monsters(inm);
            Character p = playerType.equals("1")?new Swordsman(inp, "1"):
            new Magician(inp, "1");
            
            print(m.getDescription());
            print(m.attackDialogue());
            
            int playerHealth = p.getHp();
            int monsterHealth = m.getHp();
            
                
            while(playerHealth>0 && monsterHealth>0)
            {             
                String attackIndex = sortPlayer(playerType);
                
                playerHealth = playerHealth - m.inflictDamage(inm.getMonsterType(), inp.getPlayerType(playerType,attackIndex));
                monsterHealth = monsterHealth - p.inflictDamage(inm.getMonsterType(),inp.getPlayerType(playerType,attackIndex));
                print("playerHp " + playerHealth);
                print("monsterHp" + monsterHealth);
            }
            
            printFightOutCome(playerHealth,monsterHealth,inp);
            if(playerHealth<=0){
                return;
            }
            
        }
        System.out.println("CONGRATS YOU HAVE FULFILLED THE PROPHECY!!");
    }
    
    public static String sortPlayer(String playerType)
    {
        String askAttack = "";
        if(playerType.equals("1"))
        {
            askAttack = inputString("Choose an attack\n1 for Water\n2 for Fire\nany key for Earth");
        }
        else
        {
            askAttack = inputString("Choose a sword\n1 for Long Sword\n2 for Medium Slasher\nany key for Short Dagger");
        }
        return askAttack;
    }
    
    public static void setPlayer(String name, String type, boolean vic, CharacterInfo p)
    {
        if(type.equals("1"))
        {
            p.getMagician(name, type, vic);
        }
        else
        {
            p.getSwordsMan(name, type, vic);
        }
    }
    
    public static void printFightOutCome(int playerHp, int monsterHp, CharacterInfo person)
    {
        Magician m = new Magician(person, "");
        print(m.getDescription(playerHp>0));
    }
    
    public static String getType(CharacterInfo monster)
    {
        Monsters m = new Monsters(monster);
        return m.getType();
    }
    
    public static void setMonsterValues(CharacterInfo inm, int calamityNumber)
    {
        if(calamityNumber==1)
        {
            inm.setCrimsonBat();
        }
        else if(calamityNumber==2)
        {
            inm.setBlueDragon();
        }
        else
        {
            inm.setGiantTortoise();
        }
    }
    
    public static void printIntro()
    {      
        try
        {
            BufferedReader inStream = new BufferedReader(new FileReader("intro.txt")); 
            String nextword = inStream.readLine();

            while (nextword != null)
            {
                System.out.println(nextword);
                nextword = inStream.readLine();
            }
            inStream.close();
        }
        catch(IOException e)
        {
            System.out.println("File not found!");
            e.printStackTrace();
        }       
    }

    public static String inputString(String message)
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println(message);
        String answer = scanner.nextLine();
        return answer;
    }
}