import java.lang.Math;

public class Magician extends Character
{
    private boolean victory;
    private String magicType;
    
    public Magician(CharacterInfo p, String key)
    {
        super(p.getName(), p.getHp(), p.getDamage(), p.getMobility());
        victory = p.getVictory();
        magicType = p.getMagicType(key);
    }
    
    public void setVictory(Boolean win)
    {
        victory=win;
    }

    public boolean getVictory()
    {
        return victory;
    }
    
    public String getMagicType()
    {
        return magicType;
    }
    
    public int inflictDamage(String monsterType, String magicType)
    {
        
        if(magicType.contains(monsterType)==false)
        {
            int damageMultiplier = (int)(Math.random()*3)+3;
            return ((getDamage()+((getMobility()/10)))*damageMultiplier)/10;
        }
        else
        {
            return (int)((getDamage()+((getMobility()/10))))/10;
        }
    }

    public String getDescription(boolean victory)
    {
        if(victory)
        {
            return "THREAT NULLIFIED!! MONSTER IS DEAD! MOVE ON! HEALTH RESTORED";
        }
        else
        {
            return "GAME OVER.";
        }
    }
}