import java.lang.Math;

public class Monsters extends Character
{
    private String type;
    
    public Monsters(CharacterInfo m)
    {
        super(m.getName(), m.getHp(), m.getDamage(), m.getMobility());
        type = m.getMonsterType();
    }

    public String getType()
    {
        return type;
    }
    
    public String attackDialogue()
    {
        return "A fight begins!"+ "\n" + getName() + " attacks";
    }
    
    public int inflictDamage(String monsterType, String magicType)
    {
        if(monsterType.equals("Land"))
        {
            int range=2; int min=1;
            int damageMultiplier = (int)(Math.random()*range)+min;
            return ((getDamage()+((getMobility()/10)))*damageMultiplier)/10;
        }
        else if(monsterType.equals("Water"))
        {
            int range=4; int min=2;
            int damageMultiplier = (int)(Math.random()*range)+min;
            return ((getDamage()+((getMobility()/10)))*damageMultiplier)/10;
        }
        else if(monsterType.equals(monsterType))
        {
            int range=6; int min=3;
            int damageMultiplier = (int)(Math.random()*range)+min;
            return ((getDamage()+((getMobility()/10)))*damageMultiplier)/10;
        }
        else
        {
            return ((getDamage()+((getMobility()/10))))/10;
        }
    }
    
    
    public String getDescription()
    {
        String narrative = "There is tension in the air as two sworn enemies are about to meet." + "\n";
        if(getName().equals("Giant Tortoise"))
        {
            return narrative + "You move towards a cave. Something is giving of an intense killing intent. A Giant Tortoise appears!";
        }
        else if(getName().equals("Blue Dragon"))
        {
            return narrative + "You come across still pool of water. Suddenly a Blue Dragon appears!";
        }
        else if(getName().equals("Crimson Bat"))
        {
            return narrative + "The dungeon is unusually dark. Suddenly a bright fiery light flashes across the ceiling. A Crimson Bat Appears!";
        }
        else
        {
            return narrative + "A mouse runs across from right to left.";
        }
    }
}