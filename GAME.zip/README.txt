Student name: Al-Noornabi Al-Qausayen Al-Makki
Student number: 200501192

Now complete the statements below for each level you wish to be marked. Replace all text in square brackets.

LEVEL ONE

My code demonstrates inheritance in the following way
The subclass Magician inherits the non private methods form its superclass character such as getName().


I have a superclass called [Character]

This superclass is extended into at least two subclasses called Monsters and Magician.

For each of the named subclasses complete the following...

Subclass 1.

Subclass [Magician] extends the superclass by adding at least one property and its getters and setters. The name(s) of the added properties are [getMagicType().]

These/this new properties/property are used by the subclass in the following way: [This property is used to mathc the attack or sword type to inflict multiplied damage.]

Subclass [Swordsman] extends the superclass by overriding the following methods (there must be at least one): [inflictDamage() in line 31 of subclass Magician]

These overridden methods are used in the working code in the following places: [Game class used in line56 method fight3calamities]

Subclass 2.

Subclass [Monsters] extends the superclass by adding at least one property and its getters and setters. The name(s) of the added properties are [type getType().]

These/this new properties/property are used by the subclass in the following way: [ Can return three different types of monsters that have affinities.]

Subclass [Monsters] extends the superclass by overriding the following methods (there must be at least one): [getDescription() in line 50.]

These overridden methods are used in the working code in the following places: [Game class method fight3calamities() and line44.]


LEVEL TWO

Polymorphism consists of the use of the Substitution principle and Late Dynamic binding.

In my code, polymorphism is implemented in at least two places…

Example 1.

The substitution principle can be seen in use in [Game line method fight3calamities() 41]. The name of the superclass used in this example is [Swordsman and Magician] and the subclasses used are [names of subclasses].

Late dynamic binding can be seen in [Game line method fight3calamities() 41].

[Magician and Swordsman subclasses have inherited lots of non private methods from superclass Character and because of that depending on whether we want to play as swordsman or magician we can make use of the same methods but they will have different properties for Swordsman and magician.]

Example 2.

The substitution principle can be seen in use in [Game class method fight3calamities() line 40]. The name of the superclass used in this example is [Character] and the subclasses used are [Monsters, Swordsman and Magician].

Late dynamic binding can be seen in [Game class line 40].

[The monsters class inherits properties such as name and has a overrridden methods. So if the sane method is called for new character we would get a different outcome from new monsters.]
