import java.lang.Math;

public class Swordsman extends Character
{
    private boolean victory;
    private String swordType;
    
    public Swordsman(CharacterInfo p, String key)
    {
        super(p.getName(), p.getHp(), p.getDamage(), p.getMobility());
        victory = p.getVictory();
        swordType = p.getSwordType(key);
    }
    
    public void setVictory(Boolean win)
    {
        victory=win;
    }

    public boolean getVictory()
    {
        return victory;
    }
    
    public String getSwordType()
    {
        return swordType;
    }
    
    public boolean maxSwordEffectiveness(String monster, String sword)
    {
        if ((sword.equals("Long Sword"))&&(monster.equals("Earth"))||
            (sword.equals("Medium Slasher"))&&(monster.equals("Water"))||
            (sword.equals("Light Dagger"))&&(monster.equals("Fire")))
        {
            return false;
        }
        else
        {
            return true;
        }
    }
    
    public int inflictDamage(String monsterType, String swordType)
    {
        
        if(maxSwordEffectiveness(monsterType, swordType))
        {
            int damageMultiplier = (int)(Math.random()*3)+3;
            return ((getDamage()+((getMobility()/10)))*damageMultiplier)/10;
        }
        else
        {
            return ((getDamage()+((getMobility()/10))))/10;
        }
    }

    public String getDescription(boolean victory)
    {
        if(victory)
        {
            return "THREAT NULLIFIED!! MONSTER HAS BEEN SLASHED TO BITS! HEALTH RESTORED";
        }
        else
        {
            return "GAME OVER.";
        }
    }
}
